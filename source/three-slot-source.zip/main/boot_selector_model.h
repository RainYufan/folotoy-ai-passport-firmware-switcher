// main/boot_selector_model.h
// 固件选择器菜单的纯逻辑状态机:与 ESP-IDF/LVGL 无关,可直接在宿主机测试。
#pragma once

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// 与 partitions.csv 保持一致的槽位数(硬件布局事实,仅此一处常量)。
#define BOOT_SEL_SLOT_COUNT 3

// 菜单条目数:3 个槽 + 1 个“继续上次固件”。
#define BOOT_SEL_ITEM_COUNT (BOOT_SEL_SLOT_COUNT + 1)

// 0xFF = 无上次记录。
#define BOOT_SEL_LAST_NONE 0xFF

// 无操作自动回到上次固件的倒计时(毫秒)。
#define BOOT_SEL_AUTOBOOT_TIMEOUT_MS 10000

// 菜单条目索引:0..2 为槽,3 为“继续上次固件”。
typedef struct {
    uint8_t cursor;        // 当前选中条目
    uint8_t last_slot;     // 上次启动的槽(0..2)或 BOOT_SEL_LAST_NONE
    bool    autoboot;      // 倒计时是否进行中
    uint32_t remaining_ms; // 倒计时剩余
} boot_sel_model_t;

typedef enum {
    BOOT_SEL_EVENT_NONE = 0,
    BOOT_SEL_EVENT_TIMEOUT, // 倒计时走完:启动上次固件
} boot_sel_event_t;

// last_slot 传 BOOT_SEL_LAST_NONE 表示没有记录,倒计时不启动。
void boot_sel_model_init(boot_sel_model_t *m, uint8_t last_slot);

// 光标上下移动,带环绕。返回新的光标位置。
uint8_t boot_sel_model_move(boot_sel_model_t *m, int delta);

// 任意按键输入都取消倒计时(开机误按不会意外启动固件)。
void boot_sel_model_cancel_autoboot(boot_sel_model_t *m);

// 推进 dt_ms 毫秒;倒计时走完返回 BOOT_SEL_EVENT_TIMEOUT 一次。
boot_sel_event_t boot_sel_model_tick(boot_sel_model_t *m, uint32_t dt_ms);

// NVS 里只存一个字节:上次槽位或 0xFF。
typedef struct {
    uint8_t last_slot;
} boot_sel_nvs_t;

// 校验并解析 NVS 里的字节:非法值(>=3 且 !=0xFF)返回 false。
bool boot_sel_nvs_decode(uint8_t raw, boot_sel_nvs_t *out);
uint8_t boot_sel_nvs_encode(const boot_sel_nvs_t *v);

// esp_app_desc_t 的魔数(见 esp_app_format/esp_app_desc.h)。
#define BOOT_SEL_APP_DESC_MAGIC 0xABCD5432u

// 在镜像开头 len 字节内按 4 字节对齐查找应用描述魔数;
// 返回其偏移,找不到返回 -1。纯逻辑,可在宿主机测试。
int32_t boot_sel_find_desc_offset(const uint8_t *buf, size_t len);
