// main/main.c —— 固件选择器(rec 式):开机按任意键(约 2 秒)进入本菜单,
// 平时经 otadata 直接启动上次固件。菜单里选择槽位后写入 otadata 并重启。
//
// 按键语义:
//   上/下 短按   移动选中项(任何输入都会取消自动启动倒计时)
//   确认 短按   启动选中槽位的固件;空槽位则提示
#include "boot_selector_model.h"
#include "boot_ui.h"
#include "bsp_battery.h"
#include "bsp_button.h"
#include "bsp_display.h"
#include "bsp_i2c.h"
#include "bsp_pins.h"
#include "key_guard.h"

#include "esp_app_format.h"
#include "esp_image_format.h"
#include "esp_log.h"
#include "esp_ota_ops.h"
#include "esp_partition.h"
#include "esp_system.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/task.h"
#include "lvgl.h"
#include "nvs_flash.h"

#include <string.h>

static const char *TAG = "bootsel";

static const char *const SLOT_LABELS[BOOT_SEL_SLOT_COUNT] = {
    "slot_a", "slot_b", "slot_c",
};

#define INPUT_QUEUE_DEPTH 8

typedef struct {
    bsp_btn_t btn;
    bsp_btn_ev_t event;
} input_event_t;

typedef struct {
    uint8_t slot; // 0..2 或 BOOT_SEL_LAST_NONE
} boot_action_t;

static boot_sel_model_t s_model;
static boot_slot_view_t s_slots[BOOT_SEL_SLOT_COUNT];
static const esp_partition_t *s_parts[BOOT_SEL_SLOT_COUNT];
static lv_obj_t *s_scr;
static QueueHandle_t s_input_queue;
static QueueHandle_t s_boot_queue;
static TaskHandle_t s_input_task;
static volatile bool s_input_ready;
static int s_battery_soc = -1;
static char s_status[64];
static int64_t s_status_until_us;
static key_guard_t s_key_guard;

static const char *NVS_NS = "bootsel";

// ---------------------------------------------------------------------------
// 槽位发现与镜像校验
// ---------------------------------------------------------------------------
static void sanitize(char *out, size_t out_len, const char *in) {
    size_t i = 0;
    while (i + 1 < out_len && in[i] != '\0') {
        unsigned char c = (unsigned char)in[i];
        out[i] = (c >= 0x20 && c < 0x7F) ? (char)c : '?';
        i++;
    }
    out[i] = '\0';
}

// 读取槽内镜像的 esp_app_desc_t。IDF 各版本镜像里段头既可能连续排布,
// 也可能与段数据交错(含对齐填充),但 esp_app_desc 总是 DROM 段数据的前
// 256 字节,且紧跟镜像头+首个段头之后。在镜像开头 16KB 内按 4 字节对齐
// 扫描 ESP_APP_DESC_MAGIC_WORD 即可稳定定位,不依赖具体布局。
#define DESC_SCAN_BYTES 0x4000
static uint8_t s_desc_scan[DESC_SCAN_BYTES];

static esp_err_t slot_read_desc(const esp_partition_t *part,
                                esp_app_desc_t *out) {
    if (esp_partition_read(part, 0, s_desc_scan, sizeof(s_desc_scan)) !=
        ESP_OK) {
        return ESP_FAIL;
    }
    const esp_image_header_t *hdr = (const esp_image_header_t *)s_desc_scan;
    if (hdr->magic != ESP_IMAGE_HEADER_MAGIC) {
        return ESP_ERR_IMAGE_INVALID;
    }
    int32_t off = boot_sel_find_desc_offset(s_desc_scan, sizeof(s_desc_scan));
    if (off < 0) {
        return ESP_ERR_IMAGE_INVALID;
    }
    esp_app_desc_t desc;
    if (esp_partition_read(part, (uint32_t)off, &desc, sizeof(desc)) !=
        ESP_OK) {
        return ESP_FAIL;
    }
    if (desc.magic_word != ESP_APP_DESC_MAGIC_WORD) {
        return ESP_ERR_IMAGE_INVALID;
    }
    *out = desc;
    return ESP_OK;
}

static void slots_discover(void) {
    for (int i = 0; i < BOOT_SEL_SLOT_COUNT; i++) {
        boot_slot_view_t *v = &s_slots[i];
        memset(v, 0, sizeof(*v));
        s_parts[i] = esp_partition_find_first(
            ESP_PARTITION_TYPE_APP, ESP_PARTITION_SUBTYPE_ANY, SLOT_LABELS[i]);
        if (s_parts[i] == NULL) {
            ESP_LOGW(TAG, "找不到分区 %s", SLOT_LABELS[i]);
            continue;
        }
        const esp_partition_t *part = s_parts[i];
        // 先看镜像魔数,避免对空/坏槽做解析。
        uint8_t magic = 0;
        if (esp_partition_read(part, 0, &magic, 1) != ESP_OK || magic != 0xE9) {
            continue;
        }
        esp_image_metadata_t meta;
        esp_partition_pos_t pos = {.offset = part->address, .size = part->size};
        if (esp_image_get_metadata(&pos, &meta) != ESP_OK) {
            ESP_LOGW(TAG, "%s 镜像元数据解析失败", SLOT_LABELS[i]);
            continue;
        }
        esp_app_desc_t d;
        if (slot_read_desc(part, &d) != ESP_OK) {
            ESP_LOGW(TAG, "%s 应用描述读取失败", SLOT_LABELS[i]);
            continue;
        }
        v->has_image = true;
        sanitize(v->name, sizeof(v->name), d.project_name);
        sanitize(v->version, sizeof(v->version), d.version);
        snprintf(v->date, sizeof(v->date), "%s", d.date);
        ESP_LOGI(TAG, "%s: %s %s (%s)", SLOT_LABELS[i], v->name, v->version,
                 v->date);
    }
}

// ---------------------------------------------------------------------------
// NVS:上次启动记录
// ---------------------------------------------------------------------------
static uint8_t last_slot_load(void) {
    nvs_handle_t h;
    if (nvs_open(NVS_NS, NVS_READONLY, &h) != ESP_OK) {
        return BOOT_SEL_LAST_NONE;
    }
    uint8_t raw = BOOT_SEL_LAST_NONE;
    boot_sel_nvs_t v;
    if (nvs_get_u8(h, "last", &raw) == ESP_OK && boot_sel_nvs_decode(raw, &v)) {
        nvs_close(h);
        return v.last_slot;
    }
    nvs_close(h);
    return BOOT_SEL_LAST_NONE;
}

static void last_slot_save(uint8_t slot) {
    nvs_handle_t h;
    if (nvs_open(NVS_NS, NVS_READWRITE, &h) != ESP_OK) {
        return;
    }
    boot_sel_nvs_t v = {.last_slot = slot};
    nvs_set_u8(h, "last", boot_sel_nvs_encode(&v));
    nvs_commit(h);
    nvs_close(h);
}

// ---------------------------------------------------------------------------
// 启动所选固件:写入 otadata 后重启。返回错误则留在菜单。
// ---------------------------------------------------------------------------
static esp_err_t boot_slot(uint8_t slot) {
    if (slot >= BOOT_SEL_SLOT_COUNT || s_parts[slot] == NULL ||
        !s_slots[slot].has_image) {
        return ESP_ERR_NOT_FOUND;
    }
    esp_err_t err = esp_ota_set_boot_partition(s_parts[slot]);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "写入启动分区失败: %s", esp_err_to_name(err));
        return err;
    }
    last_slot_save(slot);
    ESP_LOGI(TAG, "下次启动固件: %s (%s)", SLOT_LABELS[slot],
             s_slots[slot].name);
    return ESP_OK;
}

static void set_status(const char *text) {
    snprintf(s_status, sizeof(s_status), "%s", text);
    s_status_until_us = esp_timer_get_time() + 2500 * 1000;
}

// ---------------------------------------------------------------------------
// 输入分发(输入任务上下文,不阻塞按键回调)
// ---------------------------------------------------------------------------
static void process_input(const input_event_t *input) {
    if (input->event != BSP_BTN_CLICK) {
        return;
    }
    if (!bsp_lvgl_lock(500)) {
        return;
    }
    boot_sel_model_cancel_autoboot(&s_model);
    if (input->btn == BSP_BTN_UP) {
        boot_sel_model_move(&s_model, -1);
        set_status("");
    } else if (input->btn == BSP_BTN_DOWN) {
        boot_sel_model_move(&s_model, +1);
        set_status("");
    } else if (input->btn == BSP_BTN_OK) {
        uint8_t target =
            (s_model.cursor < BOOT_SEL_SLOT_COUNT)
                ? s_model.cursor
                : s_model.last_slot;
        if (target == BOOT_SEL_LAST_NONE) {
            set_status("还没有启动记录");
        } else if (s_slots[target].has_image) {
            set_status("正在启动…");
            boot_ui_refresh(s_scr, &s_model, s_slots, s_battery_soc, s_status);
            bsp_lvgl_unlock();
            boot_action_t action = {.slot = target};
            (void)xQueueSend(s_boot_queue, &action, 0);
            return;
        } else {
            set_status("该槽位没有固件");
        }
    }
    boot_ui_refresh(s_scr, &s_model, s_slots, s_battery_soc, s_status);
    bsp_lvgl_unlock();
}

static void input_task(void *arg) {
    (void)arg;
    input_event_t input;
    for (;;) {
        if (xQueueReceive(s_input_queue, &input, portMAX_DELAY) == pdTRUE) {
            process_input(&input);
        }
    }
}

// 执行启动动作(独立任务上下文:flash 写入不阻塞 LVGL/输入)。
static void boot_task(void *arg) {
    (void)arg;
    boot_action_t action;
    for (;;) {
        if (xQueueReceive(s_boot_queue, &action, portMAX_DELAY) != pdTRUE) {
            continue;
        }
        esp_err_t err = boot_slot(action.slot);
        if (err == ESP_OK) {
            // 给屏幕一瞬显示"正在启动…",随后重启。
            vTaskDelay(pdMS_TO_TICKS(300));
            esp_restart();
        }
        if (bsp_lvgl_lock(500)) {
            set_status("启动失败,请重试");
            boot_ui_refresh(s_scr, &s_model, s_slots, s_battery_soc, s_status);
            bsp_lvgl_unlock();
        }
    }
}

// ---------------------------------------------------------------------------
// 按键回调(esp_timer 任务):只入队。
// 开机按着键进菜单时,那颗键在整个启动期间都按着:先用 key_guard 挡住它的
// 动作(含后到的 release),直到它松手,避免"进菜单"这个手势被当成一次操作。
// ---------------------------------------------------------------------------
#define KEY_GUARD_MAX_US (10LL * 1000 * 1000)

static void on_key(bsp_btn_t btn, bsp_btn_ev_t ev, void *user) {
    (void)user;
    if (key_guard_consume(&s_key_guard, ev == BSP_BTN_RELEASE,
                          esp_timer_get_time())) {
        return;
    }
    if (!s_input_ready || !s_input_queue) {
        return;
    }
    const input_event_t input = {.btn = btn, .event = ev};
    (void)xQueueSend(s_input_queue, &input, 0);
}

// ---------------------------------------------------------------------------
// LVGL 定时器(LVGL 任务上下文):倒计时推进 + 电量/状态刷新。
// ---------------------------------------------------------------------------
static void ui_timer_cb(lv_timer_t *timer) {
    (void)timer;
    if (s_scr == NULL) {
        return;
    }
    static int64_t last_battery_us;
    int64_t now = esp_timer_get_time();
    boot_sel_event_t ev = boot_sel_model_tick(&s_model, 200);
    if (ev == BOOT_SEL_EVENT_TIMEOUT) {
        boot_action_t action = {.slot = s_model.last_slot};
        if (s_model.last_slot != BOOT_SEL_LAST_NONE) {
            (void)xQueueSend(s_boot_queue, &action, 0);
        }
    }
    if (now - last_battery_us > 5000000) {
        last_battery_us = now;
        s_battery_soc = bsp_battery_soc();
    }
    const char *status = s_status;
    if (now > s_status_until_us) {
        status = "";
    }
    boot_ui_refresh(s_scr, &s_model, s_slots, s_battery_soc, status);
}

void app_main(void) {
    ESP_LOGI(TAG, "固件选择器启动");
    esp_err_t err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ESP_ERROR_CHECK(nvs_flash_init());
    }

    bsp_i2c_init();
    if (bsp_display_init() != ESP_OK || !bsp_lvgl_init()) {
        ESP_LOGE(TAG, "显示/LVGL 初始化失败,选择器无法继续");
        return;
    }
    bsp_display_backlight(100);

    // 电量计可选:失败时界面显示 --。
    if (bsp_battery_init() != ESP_OK) {
        ESP_LOGW(TAG, "电量计不可用,界面显示 --");
        s_battery_soc = -1;
    } else {
        s_battery_soc = bsp_battery_soc();
    }

    s_input_queue = xQueueCreate(INPUT_QUEUE_DEPTH, sizeof(input_event_t));
    s_boot_queue = xQueueCreate(2, sizeof(boot_action_t));
    if (!s_input_queue || !s_boot_queue) {
        ESP_LOGE(TAG, "队列创建失败");
        return;
    }

    if (bsp_button_init(on_key, NULL) != ESP_OK) {
        ESP_LOGE(TAG, "按键初始化失败");
        return;
    }
    // 进菜单常因"开机按着键":先挡住那手势,直到按键松手。
    key_guard_arm(&s_key_guard, esp_timer_get_time(), KEY_GUARD_MAX_US);
    const bool released = bsp_button_read_mv() >= BSP_BTN_MV_RELEASED_MIN;
    key_guard_sync_released(&s_key_guard, released);

    slots_discover();

    boot_sel_model_init(&s_model, last_slot_load());
    if (xTaskCreate(input_task, "boot_input", 4096, NULL, 5, &s_input_task) !=
        pdPASS) {
        ESP_LOGE(TAG, "输入任务创建失败");
        return;
    }
    xTaskCreate(boot_task, "boot_act", 3072, NULL, 4, NULL);

    if (bsp_lvgl_lock(1000)) {
        s_scr = boot_ui_screen_create();
        boot_ui_refresh(s_scr, &s_model, s_slots, s_battery_soc, "");
        lv_timer_create(ui_timer_cb, 200, NULL);
        bsp_lvgl_unlock();
        s_input_ready = true;
    }

    ESP_LOGI(TAG, "就绪:三个槽位已扫描,等待选择");
}
