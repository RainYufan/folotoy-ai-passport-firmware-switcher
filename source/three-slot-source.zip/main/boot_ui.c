// main/boot_ui.c
// 深色列表风格界面:标题+电量、三个固件槽卡片、继续上次卡片、倒计时与状态行。
#include "boot_ui.h"

#include "bsp_pins.h"

#include <stdio.h>

// 主题色(本应用自有视觉,不复用 ui_pixel 常量)。
#define UI_BG        0x0E1420
#define UI_CARD      0x1A2332
#define UI_CARD_SEL  0x24344B
#define UI_ACCENT    0x14B8A6
#define UI_TEXT      0xF2F5F9
#define UI_MUTED     0x8A97AB

LV_FONT_DECLARE(app_font_20);
LV_FONT_DECLARE(app_font_14);

#define CARD_W 216
#define CARD_H 50
#define CARD_X ((BSP_LCD_W - CARD_W) / 2)
#define CARD_Y_FIRST 44
#define CARD_GAP 6

typedef struct {
    lv_obj_t *scr;
    lv_obj_t *title;
    lv_obj_t *battery;
    lv_obj_t *cards[BOOT_SEL_SLOT_COUNT];
    lv_obj_t *name[BOOT_SEL_SLOT_COUNT];
    lv_obj_t *meta[BOOT_SEL_SLOT_COUNT];
    lv_obj_t *last_marks[BOOT_SEL_SLOT_COUNT];
    lv_obj_t *cont_card;
    lv_obj_t *cont_name;
    lv_obj_t *cont_meta;
    lv_obj_t *footer;
    lv_obj_t *count_bar;
    lv_obj_t *count_label;
    lv_obj_t *status;
    lv_style_t style_card;
    lv_style_t style_card_sel;
} boot_ui_t;

static boot_ui_t s_ui;

static const char *const TAG_TEXT[BOOT_SEL_SLOT_COUNT] = {"A", "B", "C"};

static void style_init(boot_ui_t *ui) {
    lv_style_init(&ui->style_card);
    lv_style_set_radius(&ui->style_card, 10);
    lv_style_set_bg_color(&ui->style_card, lv_color_hex(UI_CARD));
    lv_style_set_bg_opa(&ui->style_card, LV_OPA_COVER);
    lv_style_set_border_width(&ui->style_card, 0);
    lv_style_set_pad_all(&ui->style_card, 0);

    lv_style_init(&ui->style_card_sel);
    lv_style_set_radius(&ui->style_card_sel, 10);
    lv_style_set_bg_color(&ui->style_card_sel, lv_color_hex(UI_CARD_SEL));
    lv_style_set_bg_opa(&ui->style_card_sel, LV_OPA_COVER);
    lv_style_set_border_width(&ui->style_card_sel, 2);
    lv_style_set_border_color(&ui->style_card_sel, lv_color_hex(UI_ACCENT));
    lv_style_set_border_opa(&ui->style_card_sel, LV_OPA_COVER);
    lv_style_set_pad_all(&ui->style_card_sel, 0);
}

static lv_obj_t *label_create(lv_obj_t *parent, const lv_font_t *font,
                              uint32_t color) {
    lv_obj_t *l = lv_label_create(parent);
    lv_obj_set_style_text_font(l, font, 0);
    lv_obj_set_style_text_color(l, lv_color_hex(color), 0);
    return l;
}

static lv_obj_t *slot_card_create(boot_ui_t *ui, int idx) {
    int y = CARD_Y_FIRST + idx * (CARD_H + CARD_GAP);
    lv_obj_t *card = lv_obj_create(ui->scr);
    lv_obj_remove_style_all(card);
    lv_obj_add_style(card, &ui->style_card, 0);
    lv_obj_set_pos(card, CARD_X, y);
    lv_obj_set_size(card, CARD_W, CARD_H);

    lv_obj_t *tag = lv_obj_create(card);
    lv_obj_remove_style_all(tag);
    lv_obj_set_style_radius(tag, 8, 0);
    lv_obj_set_style_bg_color(tag, lv_color_hex(UI_ACCENT), 0);
    lv_obj_set_style_bg_opa(tag, LV_OPA_20, 0);
    lv_obj_set_pos(tag, 10, (CARD_H - 30) / 2);
    lv_obj_set_size(tag, 30, 30);
    lv_obj_t *tag_l = label_create(tag, &app_font_20, UI_ACCENT);
    lv_label_set_text(tag_l, TAG_TEXT[idx]);
    lv_obj_center(tag_l);

    lv_obj_t *name = label_create(card, &app_font_14, UI_TEXT);
    lv_obj_set_pos(name, 50, 8);
    lv_obj_set_width(name, CARD_W - 50 - 44);

    lv_obj_t *meta = label_create(card, &app_font_14, UI_MUTED);
    lv_obj_set_pos(meta, 50, 28);
    lv_obj_set_width(meta, CARD_W - 50 - 44);

    lv_obj_t *mark = label_create(card, &app_font_14, UI_ACCENT);
    lv_obj_align(mark, LV_ALIGN_RIGHT_MID, -8, 0);
    lv_obj_add_flag(mark, LV_OBJ_FLAG_HIDDEN);

    ui->cards[idx] = card;
    ui->name[idx] = name;
    ui->meta[idx] = meta;
    ui->last_marks[idx] = mark;
    return card;
}

lv_obj_t *boot_ui_screen_create(void) {
    boot_ui_t *ui = &s_ui;
    lv_obj_t *scr = lv_obj_create(NULL);
    lv_obj_remove_style_all(scr);
    lv_obj_set_style_bg_color(scr, lv_color_hex(UI_BG), 0);
    lv_obj_set_style_bg_opa(scr, LV_OPA_COVER, 0);
    lv_obj_set_scrollbar_mode(scr, LV_SCROLLBAR_MODE_OFF);
    lv_obj_set_user_data(scr, ui);
    ui->scr = scr;
    style_init(ui);

    ui->title = label_create(scr, &app_font_20, UI_TEXT);
    lv_label_set_text(ui->title, "固件选择");
    lv_obj_set_pos(ui->title, 12, 10);

    ui->battery = label_create(scr, &app_font_14, UI_MUTED);
    lv_obj_align(ui->battery, LV_ALIGN_TOP_RIGHT, -12, 14);
    lv_label_set_text(ui->battery, "");

    for (int i = 0; i < BOOT_SEL_SLOT_COUNT; i++) {
        slot_card_create(ui, i);
    }

    int y = CARD_Y_FIRST + BOOT_SEL_SLOT_COUNT * (CARD_H + CARD_GAP);
    ui->cont_card = lv_obj_create(scr);
    lv_obj_remove_style_all(ui->cont_card);
    lv_obj_add_style(ui->cont_card, &ui->style_card, 0);
    lv_obj_set_pos(ui->cont_card, CARD_X, y);
    lv_obj_set_size(ui->cont_card, CARD_W, CARD_H);
    ui->cont_name = label_create(ui->cont_card, &app_font_14, UI_TEXT);
    lv_obj_set_pos(ui->cont_name, 12, 10);
    lv_label_set_text(ui->cont_name, "继续上次固件");
    ui->cont_meta = label_create(ui->cont_card, &app_font_14, UI_MUTED);
    lv_obj_set_pos(ui->cont_meta, 12, 30);

    ui->status = label_create(scr, &app_font_14, UI_MUTED);
    lv_obj_set_pos(ui->status, 12, 268);
    lv_obj_set_width(ui->status, CARD_W);
    lv_obj_set_style_text_align(ui->status, LV_TEXT_ALIGN_CENTER, 0);

    ui->count_bar = lv_bar_create(scr);
    lv_obj_set_pos(ui->count_bar, 12, 286);
    lv_obj_set_size(ui->count_bar, CARD_W, 6);
    lv_bar_set_range(ui->count_bar, 0, BOOT_SEL_AUTOBOOT_TIMEOUT_MS);
    lv_obj_set_style_radius(ui->count_bar, 3, 0);
    lv_obj_set_style_radius(ui->count_bar, 3, LV_PART_INDICATOR);
    lv_obj_set_style_bg_color(ui->count_bar, lv_color_hex(UI_CARD), 0);
    lv_obj_set_style_bg_opa(ui->count_bar, LV_OPA_COVER, 0);
    lv_obj_set_style_bg_color(ui->count_bar, lv_color_hex(UI_ACCENT),
                              LV_PART_INDICATOR);
    lv_obj_set_style_bg_opa(ui->count_bar, LV_OPA_COVER, LV_PART_INDICATOR);
    lv_obj_add_flag(ui->count_bar, LV_OBJ_FLAG_HIDDEN);

    ui->count_label = label_create(scr, &app_font_14, UI_MUTED);
    lv_obj_set_pos(ui->count_label, 12, 268);
    lv_obj_set_width(ui->count_label, CARD_W);
    lv_obj_set_style_text_align(ui->count_label, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_add_flag(ui->count_label, LV_OBJ_FLAG_HIDDEN);

    ui->footer = label_create(scr, &app_font_14, UI_MUTED);
    lv_obj_set_pos(ui->footer, 12, 296);
    lv_obj_set_width(ui->footer, CARD_W);
    lv_obj_set_style_text_align(ui->footer, LV_TEXT_ALIGN_CENTER, 0);
    lv_label_set_text(ui->footer, "上/下 选择 · 确认 启动");

    lv_screen_load(scr);
    return scr;
}

static void card_select(lv_obj_t *card, bool selected) {
    lv_obj_set_style_border_width(card, selected ? 2 : 0, 0);
}

void boot_ui_refresh(lv_obj_t *scr, const boot_sel_model_t *model,
                     const boot_slot_view_t slots[BOOT_SEL_SLOT_COUNT],
                     int battery_soc, const char *status) {
    if (scr == NULL) {
        return;
    }
    boot_ui_t *ui = lv_obj_get_user_data(scr);
    if (ui == NULL) {
        return;
    }

    if (battery_soc >= 0 && battery_soc <= 100) {
        lv_label_set_text_fmt(ui->battery, "电量 %d%%", battery_soc);
    } else {
        lv_label_set_text(ui->battery, "电量 --");
    }

    char buf[80];
    for (int i = 0; i < BOOT_SEL_SLOT_COUNT; i++) {
        const boot_slot_view_t *v = &slots[i];
        card_select(ui->cards[i], model->cursor == (uint8_t)i);
        if (v->has_image) {
            // 主行:版本+日期(唯一标识);副行:项目名。项目名相同的
            // 固件靠版本行区分。
            if (v->version[0]) {
                snprintf(buf, sizeof(buf), "v%s · %s", v->version, v->date);
                lv_label_set_text(ui->name[i], buf);
            } else {
                lv_label_set_text(ui->name[i], v->date);
            }
            lv_label_set_text(ui->meta[i],
                              v->name[0] ? v->name : "未命名固件");
        } else {
            lv_label_set_text(ui->name[i], "空槽位");
            lv_label_set_text(ui->meta[i], "尚未写入固件");
        }
        if (model->last_slot == (uint8_t)i && v->has_image) {
            lv_label_set_text(ui->last_marks[i], "上次");
            lv_obj_clear_flag(ui->last_marks[i], LV_OBJ_FLAG_HIDDEN);
        } else {
            lv_obj_add_flag(ui->last_marks[i], LV_OBJ_FLAG_HIDDEN);
        }
    }

    card_select(ui->cont_card, model->cursor == BOOT_SEL_SLOT_COUNT);
    if (model->last_slot != BOOT_SEL_LAST_NONE &&
        slots[model->last_slot].has_image) {
        snprintf(buf, sizeof(buf), "槽 %c · %s", 'A' + model->last_slot,
                 slots[model->last_slot].name[0]
                     ? slots[model->last_slot].name
                     : "未命名固件");
        lv_label_set_text(ui->cont_meta, buf);
        lv_obj_set_style_text_color(ui->cont_name, lv_color_hex(UI_TEXT), 0);
    } else {
        lv_label_set_text(ui->cont_meta, "没有启动记录");
        lv_obj_set_style_text_color(ui->cont_name, lv_color_hex(UI_MUTED), 0);
    }

    if (model->autoboot) {
        lv_bar_set_value(ui->count_bar, model->remaining_ms, LV_ANIM_OFF);
        lv_label_set_text_fmt(ui->count_label, "自动启动上次固件 %lus",
                              (unsigned long)((model->remaining_ms + 999) / 1000));
        lv_obj_clear_flag(ui->count_bar, LV_OBJ_FLAG_HIDDEN);
        lv_obj_clear_flag(ui->count_label, LV_OBJ_FLAG_HIDDEN);
    } else {
        lv_obj_add_flag(ui->count_bar, LV_OBJ_FLAG_HIDDEN);
        lv_obj_add_flag(ui->count_label, LV_OBJ_FLAG_HIDDEN);
    }

    lv_label_set_text(ui->status, status && status[0] ? status : "");
}
