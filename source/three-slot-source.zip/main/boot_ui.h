// main/boot_ui.h
// 固件选择器的界面层:深色列表风格,与基线 demo 的 pixel shell 无关。
#pragma once

#include "boot_selector_model.h"
#include "lvgl.h"

// 每个槽位在界面上的展示数据(由 main 从分区/镜像元数据填充)。
typedef struct {
    bool has_image;        // 槽内是否写入了有效固件
    char name[33];         // 应用名(净化后,可能为空)
    char version[17];      // 版本
    char date[17];         // 构建日期
} boot_slot_view_t;

// 构建整个选择器屏幕(空内容,随后用 boot_ui_refresh 填充)。
// 必须在持有 bsp_lvgl_lock 的上下文调用。
lv_obj_t *boot_ui_screen_create(void);

// 刷新整屏:标题栏、电量、三个槽卡片、继续上次卡片、倒计时、状态行。
// 必须在持有 bsp_lvgl_lock 的上下文调用。
void boot_ui_refresh(lv_obj_t *scr, const boot_sel_model_t *model,
                     const boot_slot_view_t slots[BOOT_SEL_SLOT_COUNT],
                     int battery_soc, const char *status);
