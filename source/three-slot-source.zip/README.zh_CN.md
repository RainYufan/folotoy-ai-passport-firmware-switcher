<p align="right">
  <strong>简体中文</strong> · <a href="README.md">English</a>
</p>

# AI Passport 固件启动选择器

FoloToy AI Passport(ESP32-C3 · 8 MB Flash · 240×320 屏 · 三按键)上的 rec 式固件选择器。

平时开机直接进入上次选择的固件;开机时按住任意按键约 2 秒进入本选择器,
从最多三个槽位里挑选固件,选择会写入 OTA 数据分区并重启进入。

## 工作原理

| 启动路径 | 行为 |
| --- | --- |
| 正常开机 | bootloader 按 OTA 数据分区启动上次选中的槽位固件。 |
| 开机按住按键(约 2 秒) | bootloader 的 factory-reset 引脚(GPIO0,低电平有效)擦除 OTA 数据分区,改从 factory 分区启动——即本选择器。 |
| 选择器菜单 | 列出槽 A/B/C 及各镜像内的固件名/版本,标注上次使用的槽位;选中后写入启动分区并重启进入。 |

factory-reset 钩子用 ESP-IDF 标准 bootloader 配置实现
(`CONFIG_BOOTLOADER_FACTORY_RESET`,GPIO0);进入菜单不擦除任何数据分区,
被选的固件也无需任何配合修改。

## 按键操作

- **上/下** — 移动选中项(任何输入都会取消自动启动倒计时)
- **确认** — 启动选中的固件
- 菜单空闲 10 秒会自动启动上次固件(界面有进度条);由于进入菜单会清空 OTA
  选择,这条自动兜底也能把误入菜单的情况拉回正轨。

## Flash 布局(8 MB)

| 分区 | 类型 | 偏移 | 大小 | 用途 |
| --- | --- | --- | --- | --- |
| nvs | data/nvs | 0x9000 | 0x6000 | 设置;保存上次选择记录 |
| phy_init | data/phy | 0xF000 | 0x1000 | 射频校准数据 |
| factory | app/factory | 0x10000 | 0x100000 | 本选择器 |
| otadata | data/ota | 0x110000 | 0x2000 | 启动分区选择 |
| slot_a | app/ota_0 | 0x120000 | 0x200000 | 固件槽 A |
| slot_b | app/ota_1 | 0x320000 | 0x200000 | 固件槽 B |
| slot_c | app/ota_2 | 0x520000 | 0x200000 | 固件槽 C |

槽 A 出厂预装本仓库的硬件测试应用;槽 B、C 为空,可用 esptool 单独刷入:

```bash
python -m esptool --chip esp32c3 -p <端口> -b 460800 \
    write-flash 0x320000 你的固件.bin
```

## 构建与验证

```bash
./tools/validate.sh --static     # 仓库检查 + 宿主机测试
./tools/validate.sh --firmware   # ESP-IDF 构建 + 合并镜像校验
```

通过验证、可从 `0x0` 刷写的合并镜像输出在
`build/FoloToy-AI-Passport-full.bin`。

## 文档

完整教程——文件清单、刷写指南、逐槽位安装固件、从源码构建、自定义方法与
常见问题——见 [docs/firmware-selector-tutorial.zh_CN.md](docs/firmware-selector-tutorial.zh_CN.md)
([English](docs/firmware-selector-tutorial.md))。

## 说明

- 中文界面使用 Noto Sans SC 子集字体(由 `tools/gen_fonts.sh` 生成),
  静态门里的 `tools/check_glyphs.py` 会实测字形覆盖。
- 刷写合并镜像会替换 bootloader、分区表、选择器与槽 A 内容,并可能重置 NVS
  区域;需要保留的 NVS 数据请先导出。
- 三个按键共用一条 ADC 线,在 bootloader 层面任意按键都会把 GPIO0 拉低,
  所以进菜单的手势接受三键中的任意一个,不限于 OK 键。
