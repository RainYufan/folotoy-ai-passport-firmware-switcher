// tests/test_boot_selector_model.c
// 固件选择器纯逻辑状态机的宿主机测试:无 ESP-IDF/LVGL 依赖。
#include <assert.h>
#include <stdio.h>
#include <string.h>

#include "boot_selector_model.h"

static void test_move_wraps(void) {
    boot_sel_model_t m;
    boot_sel_model_init(&m, BOOT_SEL_LAST_NONE);
    assert(m.cursor == 0);

    assert(boot_sel_model_move(&m, -1) == BOOT_SEL_ITEM_COUNT - 1);
    assert(boot_sel_model_move(&m, +1) == 0);

    for (int i = 0; i < BOOT_SEL_ITEM_COUNT; i++) {
        assert(boot_sel_model_move(&m, +1) == (uint8_t)((i + 1) % BOOT_SEL_ITEM_COUNT));
    }
    (void)boot_sel_model_move(&m, -3);
    assert(m.cursor == BOOT_SEL_ITEM_COUNT - 1 - 2);
}

static void test_autoboot_only_with_record(void) {
    boot_sel_model_t m;
    boot_sel_model_init(&m, BOOT_SEL_LAST_NONE);
    assert(!m.autoboot);
    assert(boot_sel_model_tick(&m, 100000) == BOOT_SEL_EVENT_NONE);

    boot_sel_model_init(&m, 1);
    assert(m.autoboot);
    // 未到时间不触发
    assert(boot_sel_model_tick(&m, BOOT_SEL_AUTOBOOT_TIMEOUT_MS - 1) ==
           BOOT_SEL_EVENT_NONE);
    // 恰好走完触发一次
    assert(boot_sel_model_tick(&m, 1) == BOOT_SEL_EVENT_TIMEOUT);
    // 之后不再触发
    assert(boot_sel_model_tick(&m, 1000) == BOOT_SEL_EVENT_NONE);
}

static void test_input_cancels_autoboot(void) {
    boot_sel_model_t m;
    boot_sel_model_init(&m, 2);
    boot_sel_model_cancel_autoboot(&m);
    assert(!m.autoboot);
    assert(boot_sel_model_tick(&m, 100000) == BOOT_SEL_EVENT_NONE);
}

static void test_find_desc_offset(void) {
    uint8_t buf[0x4000];
    memset(buf, 0xA5, sizeof(buf));
    assert(boot_sel_find_desc_offset(buf, sizeof(buf)) == -1);

    const uint8_t magic[4] = {0x32, 0x54, 0xCD, 0xAB}; // 0xABCD5432 LE
    // 交错布局:紧跟镜像头+首个段头(偏移 0x20)
    memcpy(buf + 0x20, magic, 4);
    assert(boot_sel_find_desc_offset(buf, sizeof(buf)) == 0x20);
    // 连续段头布局:偏移 24 + 6*8 = 72
    memset(buf + 0x20, 0xA5, 4);
    memcpy(buf + 72, magic, 4);
    assert(boot_sel_find_desc_offset(buf, sizeof(buf)) == 72);
    // 非对齐放置不会被误报
    memset(buf + 72, 0xA5, 4);
    memcpy(buf + 73, magic, 4);
    assert(boot_sel_find_desc_offset(buf, sizeof(buf)) == -1);
    // 过短输入
    assert(boot_sel_find_desc_offset(buf, 3) == -1);
    assert(boot_sel_find_desc_offset(NULL, 16) == -1);
}

static void test_nvs_codec(void) {
    boot_sel_nvs_t v;
    assert(boot_sel_nvs_decode(0, &v) && v.last_slot == 0);
    assert(boot_sel_nvs_decode(2, &v) && v.last_slot == 2);
    assert(boot_sel_nvs_decode(BOOT_SEL_LAST_NONE, &v) &&
           v.last_slot == BOOT_SEL_LAST_NONE);
    assert(!boot_sel_nvs_decode(3, &v));  // 越界
    assert(!boot_sel_nvs_decode(0xFE, &v));

    v.last_slot = 1;
    assert(boot_sel_nvs_encode(&v) == 1);
}

int main(void) {
    test_move_wraps();
    test_autoboot_only_with_record();
    test_input_cancels_autoboot();
    test_find_desc_offset();
    test_nvs_codec();
    puts("test_boot_selector_model: PASS");
    return 0;
}
