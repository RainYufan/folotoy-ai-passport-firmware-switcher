<p align="right">
  <a href="README.zh_CN.md">简体中文</a> · <strong>English</strong>
</p>

# Payloads

Prebuilt firmware images merged into the boot-selector flash layout.

| File | Source | Offset | Slot |
| --- | --- | --- | --- |
| `hwtest-app.bin` | Repository baseline hardware-test application (`main` before this branch), built with ESP-IDF 5.5.3 | 0x120000 | slot_a |

Regenerate with [`tools/build_hwtest_payload.sh`](/tools/build_hwtest_payload.sh).
Slot B and C images are not tracked; flash them per-slot with esptool as
described in the root [`README.md`](/README.md).
