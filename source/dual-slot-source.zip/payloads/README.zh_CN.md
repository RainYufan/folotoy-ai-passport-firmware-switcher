<p align="right">
  <strong>简体中文</strong> · <a href="README.md">English</a>
</p>

# 预装固件

合并进固件选择器 Flash 布局的预编译固件镜像。

| 文件 | 来源 | 偏移 | 槽位 |
| --- | --- | --- | --- |
| `hwtest-app.bin` | 仓库基线硬件测试应用(本分支改动前的 `main`),ESP-IDF 5.5.3 构建 | 0x120000 | slot_a |

用 [`tools/build_hwtest_payload.sh`](/tools/build_hwtest_payload.sh) 重新生成。
槽 B、C 的镜像不入库,按根目录 [`README.md`](/README.md) 的说明用
esptool 按槽位单独刷入。
