// components/bsp/src/bsp_button.c
// 移植自 trae_card/components/platform/platform_esp32/src/btn_iot_button.c
#include "bsp_button.h"
#include "bsp_pins.h"
#include "iot_button.h"
#include "esp_adc/adc_oneshot.h"
#include "esp_adc/adc_cali.h"
#include "esp_adc/adc_cali_scheme.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "driver/gpio.h"
#include "freertos/task.h"

static const char *TAG = "bsp_btn";

static const uint16_t BTN_MV[BSP_BTN_COUNT][2] = BSP_BTN_MV_TABLE;

static button_handle_t s_btn[BSP_BTN_COUNT];
static bsp_btn_cb_t    s_cb;
static void           *s_user;
static volatile bool   s_ready;

// ADC1 是 unit 级独占资源:iot_button 与 bsp_button_read_mv() 必须共用同一个 oneshot
// 句柄。谁第二个调 adc_oneshot_new_unit() 谁就拿到 "adc1 is already in use"。
static adc_oneshot_unit_handle_t s_adc;
static adc_cali_handle_t         s_cali;

#define BSP_BTN_ATTEN  ADC_ATTEN_DB_12       // 量程约 0~3100mV,覆盖松开态

// Use the public button-driver interface, not button_adc's global registry:
// button 4.2.0 leaves an occupied index behind when its core allocation fails.
// These static drivers and the single ADC/calibration pair are owned by BSP.
typedef struct {
    button_driver_t base;
    unsigned index;
} bsp_adc_button_t;
static bsp_adc_button_t s_drivers[BSP_BTN_COUNT];
static int64_t s_sample_time;
static int s_sample_mv = -1;
static bool s_sample_valid;

// Key lock (see BSP_BTN_CONFIRM_MS / BSP_BTN_HOLD_MS in bsp_pins.h). The ladder can
// report only one key at a time, so the three drivers share one decoded key instead
// of judging their own window independently. -1 means no key.
typedef struct {
    int locked;          // key currently reported as pressed, or -1
    int candidate;       // differing window being timed, or -1 when none is pending
    int64_t since_us;    // when the candidate window was first seen
    bool pending;        // a candidate is being timed
} bsp_btn_decoder_t;
static bsp_btn_decoder_t s_decoder = { .locked = -1, .candidate = -1 };
static volatile uint32_t s_glitches;

// Half-open windows prevent two keys from matching a shared boundary.
static int window_of(int mv) {
    if (mv < 0) return -1;   // read/conversion failure is never a key
    for (int i = 0; i < BSP_BTN_COUNT; ++i) {
        if (mv >= BTN_MV[i][0] && mv < BTN_MV[i][1]) return i;
    }
    return -1;
}

static void decoder_reset(bsp_btn_decoder_t *d) {
    *d = (bsp_btn_decoder_t){ .locked = -1, .candidate = -1 };
}

// Feed one sample's window; returns the decoded key. Pure logic for host tests.
static int decoder_feed(bsp_btn_decoder_t *d, int window, int64_t now_us) {
    if (window == d->locked) {
        // A different reading that did not last was a contact glitch: absorbed.
        if (d->pending && d->locked >= 0) ++s_glitches;
        d->pending = false;
        d->candidate = -1;
        return d->locked;
    }
    if (!d->pending || window != d->candidate) {
        d->pending = true;
        d->candidate = window;
        d->since_us = now_us;
    }
    const int64_t need_us = (int64_t)(d->locked < 0 ? BSP_BTN_CONFIRM_MS : BSP_BTN_HOLD_MS) * 1000;
    if (now_us - d->since_us >= need_us) {
        d->locked = d->candidate;
        d->pending = false;
        d->candidate = -1;
    }
    return d->locked;
}

static uint8_t button_level(button_driver_t *driver) {
    if (!s_ready) return BUTTON_INACTIVE;
    const bsp_adc_button_t *button = (const bsp_adc_button_t *)driver;
    const int64_t now = esp_timer_get_time();
    // Share one averaged reading, and one decoder step, across the three keys in a
    // polling cycle.
    if (!s_sample_valid || now - s_sample_time >= 1000) {
        int sum = 0;
        bool ok = true;
        s_sample_time = now;
        s_sample_valid = true;
        s_sample_mv = -1;
        for (int i = 0; i < CONFIG_ADC_BUTTON_SAMPLE_TIMES; ++i) {
            int raw;
            if (adc_oneshot_read(s_adc, BSP_BTN_ADC_CHANNEL, &raw) != ESP_OK) {
                ok = false;
                break;
            }
            sum += raw;
        }
        if (ok && adc_cali_raw_to_voltage(s_cali, sum / CONFIG_ADC_BUTTON_SAMPLE_TIMES,
                                         &s_sample_mv) != ESP_OK) {
            s_sample_mv = -1;
        }
        (void)decoder_feed(&s_decoder, window_of(s_sample_mv), now);
    }
    return s_decoder.locked == (int)button->index ? BUTTON_ACTIVE : BUTTON_INACTIVE;
}

static esp_err_t button_driver_delete(button_driver_t *driver) {
    (void)driver; // Static storage; shared ADC is released after all buttons.
    return ESP_OK;
}

// 每个按键把"哪个键"随回调带回来。button 组件的回调签名固定,故用 usr_data 传索引。
static void on_event(void *arg, void *usr_data, bsp_btn_ev_t ev) {
    (void)arg;
    if (!s_ready || !s_cb) return;
    s_cb((bsp_btn_t)(intptr_t)usr_data, ev, s_user);
}
static void cb_press (void *a, void *u) { on_event(a, u, BSP_BTN_PRESS);  }
static void cb_click (void *a, void *u) { on_event(a, u, BSP_BTN_CLICK);  }
static void cb_double(void *a, void *u) { on_event(a, u, BSP_BTN_DOUBLE); }
static void cb_long  (void *a, void *u) { on_event(a, u, BSP_BTN_LONG);   }
static void cb_release(void *a, void *u) { on_event(a, u, BSP_BTN_RELEASE); }

// 初始化中途失败时先停掉所有 button driver，再释放本文件持有的校准与 ADC unit。
// button driver 仍在轮询时不能先删 ADC，否则 timer callback 会访问失效句柄。
// 返回 ESP_OK 表示按键、校准与 ADC unit 都已完整回收；否则返回首个错误码，
// 供 prepare_deep_sleep 判断能否安全切回数字输入。
static esp_err_t button_cleanup(void) {
    esp_err_t first_err = ESP_OK;
    s_cb = NULL;
    s_user = NULL;
    s_ready = false;
    s_sample_valid = false;
    decoder_reset(&s_decoder);

    for (int i = BSP_BTN_COUNT - 1; i >= 0; i--) {
        if (!s_btn[i]) continue;
        esp_err_t e = iot_button_delete(s_btn[i]);
        if (e != ESP_OK) {
            ESP_LOGE(TAG, "按键 %d 回滚失败: %s", i, esp_err_to_name(e));
            if (first_err == ESP_OK) first_err = e;
            continue;
        }
        s_btn[i] = NULL;
    }

    // Never free the ADC beneath a driver whose deletion failed.
    for (int i = 0; i < BSP_BTN_COUNT; ++i) {
        if (s_btn[i]) {
            if (first_err == ESP_OK) first_err = ESP_ERR_INVALID_STATE;
            return first_err;
        }
    }

    if (s_cali) {
        esp_err_t e = adc_cali_delete_scheme_curve_fitting(s_cali);
        if (e != ESP_OK) {
            ESP_LOGE(TAG, "ADC 校准回滚失败: %s", esp_err_to_name(e));
            if (first_err == ESP_OK) first_err = e;
        } else {
            s_cali = NULL;
        }
    }
    if (s_adc) {
        esp_err_t e = adc_oneshot_del_unit(s_adc);
        if (e != ESP_OK) {
            ESP_LOGE(TAG, "ADC unit 回滚失败: %s", esp_err_to_name(e));
            if (first_err == ESP_OK) first_err = e;
        } else {
            s_adc = NULL;
        }
    }
    return first_err;
}

static esp_err_t register_callbacks(button_handle_t button, void *index) {
    esp_err_t e = iot_button_register_cb(button, BUTTON_PRESS_DOWN, NULL, cb_press, index);
    if (e == ESP_OK) e = iot_button_register_cb(button, BUTTON_SINGLE_CLICK, NULL, cb_click, index);
    if (e == ESP_OK) e = iot_button_register_cb(button, BUTTON_DOUBLE_CLICK, NULL, cb_double, index);
    if (e == ESP_OK) e = iot_button_register_cb(button, BUTTON_LONG_PRESS_START, NULL, cb_long, index);
    if (e == ESP_OK) e = iot_button_register_cb(button, BUTTON_PRESS_UP, NULL, cb_release, index);
    return e;
}

esp_err_t bsp_button_init(bsp_btn_cb_t cb, void *user) {
    if (s_ready) {
        s_cb = cb;
        s_user = user;
        return ESP_OK;
    }
    if (s_adc || s_cali) {
        ESP_LOGE(TAG, "上次按键初始化回滚不完整，拒绝覆盖仍存活的 ADC 句柄");
        return ESP_ERR_INVALID_STATE;
    }
    for (int i = 0; i < BSP_BTN_COUNT; i++) {
        if (s_btn[i]) {
            ESP_LOGE(TAG, "上次按键 %d 回滚不完整，拒绝重复分配资源", i);
            return ESP_ERR_INVALID_STATE;
        }
    }

    s_cb = cb; s_user = user;

    // BSP owns one ADC unit and one calibration handle for polling and reads.
    const adc_oneshot_unit_init_cfg_t ucfg = { .unit_id = BSP_BTN_ADC_UNIT };
    esp_err_t ae = adc_oneshot_new_unit(&ucfg, &s_adc);
    if (ae != ESP_OK) {
        ESP_LOGE(TAG, "ADC unit 创建失败 (%s)", esp_err_to_name(ae));
        s_adc = NULL;
        (void)button_cleanup();
        return ae;
    }

    const adc_oneshot_chan_cfg_t channel = {
        .atten = BSP_BTN_ATTEN,
        .bitwidth = ADC_BITWIDTH_DEFAULT,
    };
    ae = adc_oneshot_config_channel(s_adc, BSP_BTN_ADC_CHANNEL, &channel);
    if (ae != ESP_OK) { (void)button_cleanup(); return ae; }
    const adc_cali_curve_fitting_config_t cal = {
        .unit_id = BSP_BTN_ADC_UNIT,
        .chan = BSP_BTN_ADC_CHANNEL,
        .atten = BSP_BTN_ATTEN,
        .bitwidth = ADC_BITWIDTH_DEFAULT,
    };
    ae = adc_cali_create_scheme_curve_fitting(&cal, &s_cali);
    if (ae != ESP_OK) {
        ESP_LOGE(TAG, "ADC 校准创建失败: %s", esp_err_to_name(ae));
        (void)button_cleanup();
        return ae; // No guessed mV: an unavailable reading is not an UP press.
    }

    for (int i = 0; i < BSP_BTN_COUNT; i++) {
        s_drivers[i] = (bsp_adc_button_t){
            .base = { .get_key_level = button_level, .del = button_driver_delete },
            .index = (unsigned)i,
        };
        // 判定门限由 BSP 显式下发(见 bsp_pins.h):组件 Kconfig 默认的长按 1500ms 偏迟钝。
        const button_config_t bc = {
            .short_press_time = BSP_BTN_SHORT_PRESS_MS,
            .long_press_time  = BSP_BTN_LONG_PRESS_MS,
        };
        esp_err_t e = iot_button_create(&bc, &s_drivers[i].base, &s_btn[i]);
        if (e != ESP_OK || !s_btn[i]) {
            ESP_LOGE(TAG, "按键 %d 创建失败 (%s) —— 检查 GPIO%d 的 ADC 配置与分压电阻",
                     i, esp_err_to_name(e), BSP_BTN_ADC_CHANNEL);
            e = e == ESP_OK ? ESP_FAIL : e;
            (void)button_cleanup();
            return e;
        }
        void *idx = (void *)(intptr_t)i;
        e = register_callbacks(s_btn[i], idx);
        if (e != ESP_OK) {
            ESP_LOGE(TAG, "按键 %d 回调注册失败: %s", i, esp_err_to_name(e));
            (void)button_cleanup();
            return e;
        }
    }

    s_sample_valid = false;
    decoder_reset(&s_decoder);
    s_ready = true;
    ESP_LOGI(TAG, "按键就绪:ADC1_CH%d 三键分压,短按 %dms 长按 %dms",
             BSP_BTN_ADC_CHANNEL, BSP_BTN_SHORT_PRESS_MS, BSP_BTN_LONG_PRESS_MS);
    return ESP_OK;
}

uint32_t bsp_button_glitch_count(void) {
    return s_glitches;
}

int bsp_button_read_mv(void) {
    // 读的是 bsp_button_init() 建好、并与 iot_button 共用的那一路 ADC。
    // 单次采样与组件的按键轮询互不干扰(oneshot 内部自带锁)。
    if (!s_adc || !s_cali) return -1;

    int raw = 0, mv = 0;
    if (adc_oneshot_read(s_adc, BSP_BTN_ADC_CHANNEL, &raw) != ESP_OK) return -1;
    if (adc_cali_raw_to_voltage(s_cali, raw, &mv) != ESP_OK) return -1;
    return mv;
}

esp_err_t bsp_button_prepare_deep_sleep(int *level) {
    if (level) *level = 0;

    // ① 先停按键驱动,再放 ADC —— 反过来会让 timer 回调碰到已释放的句柄。
    // 回滚不完整时(仍有存活的按键句柄或 ADC unit)不能切回数字输入:否则
    // 既留下仍会轮询的驱动,又让调用方误以为可以安全入睡。
    esp_err_t err = button_cleanup();
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "按键/ADC 回滚不完整,拒绝切回数字输入: %s", esp_err_to_name(err));
        return err;
    }

    // ② 按键脚交回普通数字输入 + 上拉(与板上 10k 外部上拉并联)。
    const gpio_num_t pin = (gpio_num_t)BSP_BTN_GPIO;
    err = gpio_set_direction(pin, GPIO_MODE_INPUT);
    if (err == ESP_OK) err = gpio_set_pull_mode(pin, GPIO_PULLUP_ONLY);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "按键脚切回数字输入失败: %s", esp_err_to_name(err));
        return err;
    }

    // 上拉建立需要一点时间,再回读。
    vTaskDelay(pdMS_TO_TICKS(20));
    if (level) *level = gpio_get_level(pin);
    ESP_LOGI(TAG, "按键已释放,深睡唤醒脚 GPIO%d 电平=%d", (int)pin, level ? *level : -1);
    return ESP_OK;
}
