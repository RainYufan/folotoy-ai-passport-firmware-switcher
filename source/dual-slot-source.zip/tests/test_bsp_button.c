// Execute the real BSP with public-interface stubs and a fake ADC (no SDK needed).
#include <assert.h>
#include <stddef.h>
#include <stdio.h>
#include "../components/bsp/src/bsp_button.c"

struct button_dev_t { button_driver_t *driver; bool live; };
static struct button_dev_t buttons[BSP_BTN_COUNT];
static int adc_token, cal_token, adc_live, cal_live, live_buttons;
static int create_calls, callback_calls, fail_create, fail_callback;
static int fail_adc, fail_channel, fail_cal, fail_read, fail_convert, fail_delete;
static int raw_mv, reads, events;
static int64_t clock_us;

esp_err_t adc_oneshot_new_unit(const adc_oneshot_unit_init_cfg_t *cfg, adc_oneshot_unit_handle_t *h) {
    assert(cfg->unit_id == BSP_BTN_ADC_UNIT && !adc_live);
    if (fail_adc) return ESP_ERR_NO_MEM;
    adc_live = 1; *h = &adc_token; return ESP_OK;
}
esp_err_t adc_oneshot_del_unit(adc_oneshot_unit_handle_t h) {
    assert(h == &adc_token && adc_live && !live_buttons);
    adc_live = 0; return ESP_OK;
}
esp_err_t adc_oneshot_config_channel(adc_oneshot_unit_handle_t h, int channel, const adc_oneshot_chan_cfg_t *cfg) {
    assert(h == &adc_token && channel == BSP_BTN_ADC_CHANNEL && cfg->atten == ADC_ATTEN_DB_12);
    return fail_channel ? ESP_FAIL : ESP_OK;
}
esp_err_t adc_oneshot_read(adc_oneshot_unit_handle_t h, int channel, int *raw) {
    assert(h == &adc_token && adc_live && channel == BSP_BTN_ADC_CHANNEL);
    ++reads;
    if (fail_read) return ESP_FAIL;
    *raw = raw_mv; return ESP_OK;
}
esp_err_t adc_cali_create_scheme_curve_fitting(const adc_cali_curve_fitting_config_t *cfg, adc_cali_handle_t *h) {
    assert(adc_live && !cal_live && cfg->atten == ADC_ATTEN_DB_12);
    if (fail_cal) return ESP_ERR_NO_MEM;
    cal_live = 1; *h = &cal_token; return ESP_OK;
}
esp_err_t adc_cali_delete_scheme_curve_fitting(adc_cali_handle_t h) {
    assert(h == &cal_token && cal_live && !live_buttons);
    cal_live = 0; return ESP_OK;
}
esp_err_t adc_cali_raw_to_voltage(adc_cali_handle_t h, int raw, int *mv) {
    assert(h == &cal_token && cal_live);
    if (fail_convert) { *mv = 0; return ESP_FAIL; }
    *mv = raw; return ESP_OK;
}
int64_t esp_timer_get_time(void) { return clock_us; }

// GPIO + delay stubs for the deep-sleep hand-off (see bsp_button_prepare_deep_sleep).
static int gpio_direction_calls, gpio_pull_calls, gpio_level_calls, delay_calls, fail_gpio;
static gpio_num_t gpio_last_pin;
static gpio_mode_t gpio_last_mode;
static gpio_pull_mode_t gpio_last_pull;
static int gpio_level = 1;

esp_err_t gpio_set_direction(gpio_num_t pin, gpio_mode_t mode) {
    ++gpio_direction_calls; gpio_last_pin = pin; gpio_last_mode = mode;
    return fail_gpio ? ESP_FAIL : ESP_OK;
}
esp_err_t gpio_set_pull_mode(gpio_num_t pin, gpio_pull_mode_t pull) {
    ++gpio_pull_calls; gpio_last_pin = pin; gpio_last_pull = pull;
    return fail_gpio ? ESP_FAIL : ESP_OK;
}
int gpio_get_level(gpio_num_t pin) {
    (void)pin; ++gpio_level_calls; return gpio_level;
}
void vTaskDelay(TickType_t ticks) {
    (void)ticks; ++delay_calls;
}
esp_err_t iot_button_create(const button_config_t *cfg, const button_driver_t *driver, button_handle_t *h) {
    // 判定门限必须由 BSP 显式下发(bsp_pins.h),不能退回组件默认的 180 / 1500ms。
    assert(cfg->short_press_time == BSP_BTN_SHORT_PRESS_MS);
    assert(cfg->long_press_time == BSP_BTN_LONG_PRESS_MS);
    if (++create_calls == fail_create) return ESP_ERR_NO_MEM;
    for (int i = 0; i < BSP_BTN_COUNT; ++i) {
        if (buttons[i].live) continue;
        buttons[i] = (struct button_dev_t){ .driver = (button_driver_t *)driver, .live = true };
        *h = &buttons[i]; ++live_buttons;
        assert(driver->get_key_level((button_driver_t *)driver) == BUTTON_INACTIVE);
        return ESP_OK;
    }
    assert(false); return ESP_FAIL;
}
esp_err_t iot_button_delete(button_handle_t h) {
    assert(h && h->live && adc_live && cal_live);
    if (fail_delete) return ESP_FAIL;
    assert(h->driver->del(h->driver) == ESP_OK);
    h->live = false; --live_buttons; return ESP_OK;
}
esp_err_t iot_button_register_cb(button_handle_t h, button_event_t ev, button_event_args_t *args, button_cb_t cb, void *u) {
    (void)args; (void)ev;
    assert(h->live);
    cb(h, u); // No user callbacks may escape a partial initialization.
    return ++callback_calls == fail_callback ? ESP_ERR_NO_MEM : ESP_OK;
}
static void event_cb(bsp_btn_t btn, bsp_btn_ev_t ev, void *u) {
    assert(btn == BSP_BTN_OK && ev == BSP_BTN_CLICK && u == &events);
    ++events;
}
static void reset_faults(void) {
    fail_adc = fail_channel = fail_cal = fail_read = fail_convert = fail_delete = 0;
    fail_create = fail_callback = create_calls = callback_calls = 0;
}
static void assert_clean(void) {
    assert(!adc_live && !cal_live && !live_buttons && !s_ready && !s_adc && !s_cali);
    for (int i = 0; i < BSP_BTN_COUNT; ++i) assert(!s_btn[i]);
}

// The board hands the shared ADC key pad back to a plain digital input before
// deep sleep: the drivers and the ADC must be released, the pin must get its
// pull-up back, and the sampled level must be reported so the caller can skip
// sleeping while a key is still held down.
static void check_deep_sleep_prepare(void) {
    reset_faults();
    gpio_direction_calls = gpio_pull_calls = gpio_level_calls = delay_calls = 0;
    fail_gpio = 0; gpio_level = 1;
    assert(bsp_button_init(event_cb, &events) == ESP_OK);

    int level = -1;
    assert(bsp_button_prepare_deep_sleep(&level) == ESP_OK);
    assert(level == 1);
    assert(gpio_direction_calls == 1 && gpio_pull_calls == 1 && gpio_level_calls == 1);
    assert(delay_calls == 1);                       // let the pull-up settle first
    assert(gpio_last_pin == BSP_BTN_GPIO);
    assert(gpio_last_mode == GPIO_MODE_INPUT);
    assert(gpio_last_pull == GPIO_PULLUP_ONLY);
    assert_clean();                                 // nothing may touch the pad afterwards

    // A key still held low is reported as 0 so the caller can refuse to sleep.
    gpio_level = 0; level = -1;
    assert(bsp_button_prepare_deep_sleep(&level) == ESP_OK);
    assert(level == 0);

    // A pin failure is propagated instead of being reported as an idle pad.
    fail_gpio = 1; level = -1;
    assert(bsp_button_prepare_deep_sleep(&level) == ESP_FAIL);
    assert(level == 0);
    fail_gpio = 0;

    assert(bsp_button_prepare_deep_sleep(NULL) == ESP_OK);   // level is optional

    // A teardown failure must be reported and must NOT reconfigure the pin: leaving
    // a live driver or ADC unit behind while the caller heads toward deep sleep would
    // be silent corruption, so the hand-off refuses to proceed.
    assert(bsp_button_init(event_cb, &events) == ESP_OK);    // re-arm live drivers
    gpio_direction_calls = gpio_pull_calls = gpio_level_calls = 0;
    fail_delete = 1; level = -1;
    assert(bsp_button_prepare_deep_sleep(&level) != ESP_OK);
    assert(level == 0);
    assert(gpio_direction_calls == 0 && gpio_pull_calls == 0 && gpio_level_calls == 0);
    fail_delete = 0;
    assert(button_cleanup() == ESP_OK);                     // now clean up for real
    assert_clean();

    assert(bsp_button_init(event_cb, &events) == ESP_OK);    // the BSP stays reusable
}
static void retry_success(void) {
    assert_clean(); reset_faults();
    assert(bsp_button_init(event_cb, &events) == ESP_OK);
    assert(create_calls == BSP_BTN_COUNT && live_buttons == BSP_BTN_COUNT);
    assert(bsp_button_init(event_cb, &events) == ESP_OK);
    assert(create_calls == BSP_BTN_COUNT);
    (void)button_cleanup(); assert_clean();
}
// One button-component polling cycle (5 ms): every driver asks for its level.
static int poll(void) {
    clock_us += 5000;
    int active = -1;
    for (int i = 0; i < BSP_BTN_COUNT; ++i) {
        if (s_drivers[i].base.get_key_level(&s_drivers[i].base) == BUTTON_ACTIVE) {
            assert(active == -1);   // never two keys at once
            active = i;
        }
    }
    return active;
}
// Hold a voltage for ms and return the decoded key afterwards.
static int hold(int mv, int ms) {
    raw_mv = mv;
    int active = -1;
    for (int t = 0; t < ms; t += 5) active = poll();
    return active;
}
static void check_voltage(int mv, int expected) {
    assert(hold(mv, 200) == expected);   // longer than confirm and hold windows
    const int before = reads;
    assert(poll() == expected);
    assert(reads - before == CONFIG_ADC_BUTTON_SAMPLE_TIMES);   // one shared sample
}

// Issue #97: a contact break inside a held key sweeps the voltage up through the
// windows above it. The lock must neither report the neighbour nor end the hold.
static void check_key_lock(void) {
    const int released = 3300, up = 50, down = 300, ok = 600;
    assert(hold(released, 200) == -1);

    // Press-down: a key must be stable for the confirm time, and the windows swept
    // through while the voltage falls are never reported.
    assert(hold(ok, 20) == -1 && hold(down, 20) == -1);
    assert(hold(up, BSP_BTN_CONFIRM_MS - 10) == -1);
    assert(hold(up, 20) == BSP_BTN_UP);

    // Held UP: a contact break dwells in DOWN, OK, then released for tens of ms
    // each, far longer than the component's ~10 ms debounce, then recovers.
    const uint32_t glitches = bsp_button_glitch_count();
    for (int i = 0; i < 5; ++i) {
        assert(hold(down, 30) == BSP_BTN_UP);
        assert(hold(ok, 40) == BSP_BTN_UP);
        assert(hold(released, 40) == BSP_BTN_UP);
        assert(hold(up, 30) == BSP_BTN_UP);
    }
    assert(bsp_button_glitch_count() == glitches + 5);

    // A real release is reported once it lasts the hold time, including the sweep
    // through the upper windows on the way out.
    assert(hold(down, 10) == BSP_BTN_UP && hold(ok, 10) == BSP_BTN_UP);
    assert(hold(released, BSP_BTN_HOLD_MS - 10) == BSP_BTN_UP);
    assert(hold(released, 20) == -1);

    // A failed read counts as "no key": it cannot press, and a held key survives it.
    fail_read = 1; assert(hold(0, 200) == -1); fail_read = 0;
    assert(hold(ok, 100) == BSP_BTN_OK);
    fail_read = 1; assert(hold(0, 60) == BSP_BTN_OK); fail_read = 0;
    assert(hold(ok, 20) == BSP_BTN_OK);
    assert(hold(released, 200) == -1);

    // Re-initialization after a teardown starts from "no key" again.
    assert(hold(down, 100) == BSP_BTN_DOWN);
    assert(button_cleanup() == ESP_OK);
    assert(bsp_button_init(event_cb, &events) == ESP_OK);
    raw_mv = released;
    assert(poll() == -1);
    assert(hold(released, 200) == -1);
}
int main(void) {
    for (int i = 1; i <= BSP_BTN_COUNT; ++i) {
        reset_faults(); fail_create = i;
        assert(bsp_button_init(event_cb, &events) != ESP_OK); retry_success();
    }
    for (int i = 1; i <= BSP_BTN_COUNT * 5; ++i) {
        reset_faults(); fail_callback = i;
        assert(bsp_button_init(event_cb, &events) != ESP_OK); retry_success();
    }
    reset_faults(); fail_adc = 1;
    assert(bsp_button_init(event_cb, &events) != ESP_OK); retry_success();
    fail_channel = 1;
    assert(bsp_button_init(event_cb, &events) != ESP_OK); retry_success();
    fail_cal = 1;
    assert(bsp_button_init(event_cb, &events) != ESP_OK); retry_success();
    assert(events == 0);
    assert(bsp_button_init(event_cb, &events) == ESP_OK);
    cb_click(NULL, (void *)(intptr_t)BSP_BTN_OK); assert(events == 1);
    check_voltage(0, BSP_BTN_UP); check_voltage(149, BSP_BTN_UP);
    check_voltage(150, BSP_BTN_DOWN); check_voltage(446, BSP_BTN_DOWN);
    check_voltage(447, BSP_BTN_OK); check_voltage(1899, BSP_BTN_OK);
    check_voltage(1900, -1); check_voltage(3300, -1);
    assert(bsp_button_read_mv() == 3300);
    check_key_lock();
    fail_read = 1; clock_us += 2000;
    for (int i = 0; i < BSP_BTN_COUNT; ++i) assert(!button_level(&s_drivers[i].base));
    assert(bsp_button_read_mv() == -1);
    fail_read = 0; fail_convert = 1; clock_us += 2000;
    for (int i = 0; i < BSP_BTN_COUNT; ++i) assert(!button_level(&s_drivers[i].base));
    assert(bsp_button_read_mv() == -1);
    fail_delete = 1; assert(button_cleanup() != ESP_OK);
    assert(adc_live && cal_live && live_buttons == BSP_BTN_COUNT);
    assert(bsp_button_init(event_cb, &events) == ESP_ERR_INVALID_STATE);
    fail_delete = 0; assert(button_cleanup() == ESP_OK); retry_success();
    check_deep_sleep_prepare();
    puts("BSP button fault-injection and key-lock tests: PASS");
}
