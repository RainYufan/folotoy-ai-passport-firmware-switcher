#!/usr/bin/env python3
"""Verify the boot-selector partition layout in partitions.csv.

Mirrors the parts of tools/verify_firmware.py that are checkable before a
build: bounds, alignment, labels, no overlap, and the expected app slots.
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
FLASH_SIZE = 8 * 1024 * 1024
EXPECTED = [
    # (label, kind, subtype, offset, size)
    ("nvs", "data", "nvs", 0x9000, 0x6000),
    ("phy_init", "data", "phy", 0xF000, 0x1000),
    ("factory", "app", "factory", 0x10000, 0xC0000),
    ("otadata", "data", "ota", 0xD0000, 0x2000),
    ("slot_a", "app", "ota_0", 0xE0000, 0x390000),
    ("slot_b", "app", "ota_1", 0x470000, 0x390000),
]


def parse_table(path: Path) -> list[tuple[str, str, str, int, int]]:
    rows = []
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        fields = [f.strip() for f in line.rstrip(",").split(",")]
        if len(fields) != 5:
            raise SystemExit(f"bad row: {raw!r}")
        label, kind, subtype = fields[0], fields[1], fields[2]
        offset, size = int(fields[3], 0), int(fields[4], 0)
        rows.append((label, kind, subtype, offset, size))
    return rows


def main() -> int:
    rows = parse_table(ROOT / "partitions.csv")
    labels = [r[0] for r in rows]
    if len(labels) != len(set(labels)):
        print("ERROR: duplicate partition labels", file=sys.stderr)
        return 1

    ordered = sorted(rows, key=lambda r: r[3])
    for r in ordered:
        if r[3] % 0x1000 or r[4] % 0x1000:
            print(f"ERROR: {r[0]} not 4 KB aligned", file=sys.stderr)
            return 1
        if r[3] < 0x9000 or r[3] + r[4] > FLASH_SIZE:
            print(f"ERROR: {r[0]} outside flash", file=sys.stderr)
            return 1
    for left, right in zip(ordered, ordered[1:]):
        if left[3] + left[4] > right[3]:
            print(f"ERROR: {left[0]} overlaps {right[0]}", file=sys.stderr)
            return 1

    if ordered != EXPECTED:
        print("ERROR: layout differs from expected plan", file=sys.stderr)
        print(ordered, file=sys.stderr)
        return 1

    app_slots = [r for r in rows if r[1] == "app"]
    if len(app_slots) != 3:  # factory + 2 slots
        print("ERROR: expected factory plus two slots", file=sys.stderr)
        return 1
    for label, _, subtype, _, size in app_slots[1:]:
        if not subtype.startswith("ota_") or size != 0x390000:
            print(f"ERROR: {label} must be a 0x390000 ota slot", file=sys.stderr)
            return 1

    print("partition layout: PASS")
    return 0


if __name__ == "__main__":
    sys.exit(main())
