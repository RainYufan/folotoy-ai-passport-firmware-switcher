#!/usr/bin/env bash
set -euo pipefail

# Usage: install-actionlint.sh [--cached-only] [destination]
# --cached-only prints an already downloaded binary and exits 3 when there is none,
# without touching the network.
version="1.7.12"
cached_only=0
if [[ "${1:-}" == "--cached-only" ]]; then
    cached_only=1
    shift
fi
destination="${1:-/tmp/actionlint-${version}}"
system_name="$(uname -s)"
machine_name="$(uname -m)"

if [[ -x "${destination}/actionlint" ]]; then
    printf '%s\n' "${destination}/actionlint"
    exit 0
fi
if [[ -x "${destination}/actionlint.exe" ]]; then
    printf '%s\n' "${destination}/actionlint.exe"
    exit 0
fi
if [[ "${cached_only}" == 1 ]]; then
    exit 3
fi

case "${system_name}/${machine_name}" in
    Linux/x86_64)
        platform="linux_amd64"
        checksum="8aca8db96f1b94770f1b0d72b6dddcb1ebb8123cb3712530b08cc387b349a3d8"
        ;;
    Linux/aarch64|Linux/arm64)
        platform="linux_arm64"
        checksum="325e971b6ba9bfa504672e29be93c24981eeb1c07576d730e9f7c8805afff0c6"
        ;;
    Darwin/x86_64)
        platform="darwin_amd64"
        checksum="5b44c3bc2255115c9b69e30efc0fecdf498fdb63c5d58e17084fd5f16324c644"
        ;;
    Darwin/arm64)
        platform="darwin_arm64"
        checksum="aba9ced2dee8d27fecca3dc7feb1a7f9a52caefa1eb46f3271ea66b6e0e6953f"
        ;;
    MINGW64_NT*/x86_64|MSYS_NT*/x86_64|CYGWIN_NT*/x86_64)
        platform="windows_amd64"
        checksum="6e7241b51e6817ea6a047693d8e6fed13b31819c9a0dd6c5a726e1592d22f6e9"
        ;;
    *)
        echo "Unsupported actionlint platform: ${system_name}/${machine_name}" >&2
        exit 1
        ;;
esac

archive_ext="tar.gz"
if [[ "${platform}" == windows_* ]]; then
    archive_ext="zip"
fi
archive_name="actionlint_${version}_${platform}.${archive_ext}"
archive_path="${destination}/${archive_name}"
download_url="https://github.com/rhysd/actionlint/releases/download/v${version}/${archive_name}"

mkdir -p "${destination}"
if ! curl --fail --location --silent --show-error --retry 3 --retry-all-errors \
    "${download_url}" --output "${archive_path}"; then
    if ! command -v gh >/dev/null 2>&1; then
        echo "actionlint download failed and GitHub CLI is unavailable" >&2
        exit 1
    fi
    rm -f "${archive_path}"
    gh release download "v${version}" --repo rhysd/actionlint \
        --pattern "${archive_name}" --dir "${destination}"
fi
# macOS can ship a BSD-style sha256sum without --check support, so only the
# non-Darwin path may rely on GNU sha256sum; elsewhere shasum verifies.
if [[ "${system_name}" != "Darwin" ]] && command -v sha256sum >/dev/null 2>&1; then
    printf '%s  %s\n' "${checksum}" "${archive_path}" | sha256sum --check --status
elif command -v shasum >/dev/null 2>&1; then
    # Compare explicitly: under stock macOS bash 3.2, set -e does not act on a
    # failing [[ ]] in an if/elif body, so a bare test would pass a mismatch.
    [[ "$(shasum -a 256 "${archive_path}" | awk '{print $1}')" == "${checksum}" ]] \
        || { echo "actionlint checksum mismatch" >&2; exit 1; }
else
    echo "No SHA-256 verification tool is available" >&2
    exit 1
fi
if [[ "${platform}" == windows_* ]]; then
    # Windows ships a zip; GNU tar cannot read zip, so extract with the
    # Windows bundled bsdtar using native paths (cygpath converts for Git Bash).
    /c/Windows/System32/tar.exe -xf "$(cygpath -w "${archive_path}")" \
        -C "$(cygpath -w "${destination}")" actionlint.exe
    chmod +x "${destination}/actionlint.exe"
    printf '%s\n' "${destination}/actionlint.exe"
else
    tar -xzf "${archive_path}" -C "${destination}" actionlint
    chmod +x "${destination}/actionlint"
    printf '%s\n' "${destination}/actionlint"
fi
