#!/usr/bin/env bash
# 重新生成固件选择器的中文字体子集(assets/fonts/app_font_14.c / app_font_20.c)。
#
# 依赖:
#   - lv_font_conv 1.5.3(本地 npm 安装,路径可用 LV_FONT_CONV 覆盖)
#   - Noto Sans SC 500 Medium .ttf(SIL OFL 1.1,路径可用 NOTO_SC_TTF 覆盖)
#
# 字符集规则:main/*.c 字符串字面量里出现的全部非 ASCII 字符 + ASCII 0x20-0x7E。
# 生成后必须运行 ./tools/validate.sh --static,其中的 check_glyphs.py 会按
# 字体 cmap 实测覆盖并拒绝缺字。
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.."

LV_FONT_CONV_BIN="${LV_FONT_CONV:-${HOME}/.dsh/tools/node_modules/.bin/lv_font_conv}"
NOTO_SC_TTF="${NOTO_SC_TTF:-${HOME}/.dsh/fontpkgs/node_modules/.pnpm/@expo-google-fonts+noto-sans-sc@0.4.4/node_modules/@expo-google-fonts/noto-sans-sc/500Medium/NotoSansSC_500Medium.ttf}"

RANGE="$(
python3 - <<'PY'
import re
from pathlib import Path
cps = set(range(0x20, 0x7F))
for f in Path("main").glob("*.c"):
    if f.name.startswith("app_font"):
        continue
    for lit in re.findall(r'"((?:[^"\\]|\\.)*)"', f.read_text(encoding="utf-8")):
        cps.update(ord(c) for c in lit if ord(c) > 0x7E)
cps = sorted(cps)
runs, start, prev = [], cps[0], cps[0]
for cp in cps[1:]:
    if cp == prev + 1:
        prev = cp
    else:
        runs.append((start, prev)); start = prev = cp
runs.append((start, prev))
print(",".join(f"0x{a:X}" if a == b else f"0x{a:X}-0x{b:X}" for a, b in runs))
PY
)"

for spec in "20:app_font_20" "14:app_font_14"; do
    size="${spec%%:*}"; name="${spec##*:}"
    "${LV_FONT_CONV_BIN}" \
        --font "${NOTO_SC_TTF}" \
        --size "${size}" --bpp 4 --format lvgl --no-compress \
        --lv-font-name "${name}" --lv-include lvgl.h \
        --range "${RANGE}" \
        --output "assets/fonts/${name}.c"
    echo "generated assets/fonts/${name}.c (size ${size}, range ${RANGE})"
done
