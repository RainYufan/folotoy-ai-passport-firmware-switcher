#!/usr/bin/env bash
# 构建槽 A 预装固件:仓库基线硬件测试应用(本分支改动前的 main)。
# 产出 payloads/hwtest-app.bin,由 main/CMakeLists.txt 合并进 full.bin 的 slot_a。
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.."
ROOT="$(pwd)"

BASELINE="${BASELINE_COMMIT:-$(git rev-list --max-parents=0 HEAD)}"
IDF_ROOT="${AI_PASSPORT_IDF_ROOT:-${HOME}/esp/esp-idf-v5.5.3}"
TMP="$(mktemp -d /tmp/ai-passport-hwtest.XXXXXX)"
trap 'git worktree remove --force "${TMP}/wt" 2>/dev/null || true; rm -rf "${TMP}"' EXIT

echo "baseline commit: ${BASELINE}"
git worktree add -q "${TMP}/wt" "${BASELINE}"

(
    cd "${TMP}/wt"
    # 槽 A 的硬件测试用独立项目名,菜单里才能与其它固件区分开。
    sed -i.bak 's/project(FoloToy-AI-Passport)/project(AI-Passport-HwTest)/' CMakeLists.txt
    rm -f CMakeLists.txt.bak
    . "${IDF_ROOT}/export.sh" >/dev/null 2>&1
    idf.py -B "${TMP}/build" -D "SDKCONFIG=${TMP}/build/sdkconfig" set-target esp32c3
    idf.py -B "${TMP}/build" -D "SDKCONFIG=${TMP}/build/sdkconfig" build
    install -m 0644 "${TMP}/build/AI-Passport-HwTest.bin" \
        "${ROOT}/payloads/hwtest-app.bin"
)
echo "payloads/hwtest-app.bin updated"
ls -la "${ROOT}/payloads/hwtest-app.bin"
