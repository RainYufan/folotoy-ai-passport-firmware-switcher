// main/boot_selector_model.c
#include "boot_selector_model.h"

static bool valid_last(uint8_t v) {
    return v == BOOT_SEL_LAST_NONE || v < BOOT_SEL_SLOT_COUNT;
}

void boot_sel_model_init(boot_sel_model_t *m, uint8_t last_slot) {
    m->cursor = 0;
    m->last_slot = last_slot;
    // 有记录才自动倒计时;没有记录就停在菜单等用户选择。
    m->autoboot = (last_slot != BOOT_SEL_LAST_NONE) && valid_last(last_slot);
    m->remaining_ms = BOOT_SEL_AUTOBOOT_TIMEOUT_MS;
}

uint8_t boot_sel_model_move(boot_sel_model_t *m, int delta) {
    int cur = (int)m->cursor + delta;
    cur %= BOOT_SEL_ITEM_COUNT;
    if (cur < 0) {
        cur += BOOT_SEL_ITEM_COUNT;
    }
    m->cursor = (uint8_t)cur;
    return m->cursor;
}

void boot_sel_model_cancel_autoboot(boot_sel_model_t *m) {
    m->autoboot = false;
    m->remaining_ms = 0;
}

boot_sel_event_t boot_sel_model_tick(boot_sel_model_t *m, uint32_t dt_ms) {
    if (!m->autoboot) {
        return BOOT_SEL_EVENT_NONE;
    }
    if (dt_ms >= m->remaining_ms) {
        m->remaining_ms = 0;
        m->autoboot = false; // 只触发一次,由调用方执行启动
        return BOOT_SEL_EVENT_TIMEOUT;
    }
    m->remaining_ms -= dt_ms;
    return BOOT_SEL_EVENT_NONE;
}

bool boot_sel_nvs_decode(uint8_t raw, boot_sel_nvs_t *out) {
    if (!valid_last(raw)) {
        return false;
    }
    out->last_slot = raw;
    return true;
}

uint8_t boot_sel_nvs_encode(const boot_sel_nvs_t *v) {
    return v->last_slot;
}

int32_t boot_sel_find_desc_offset(const uint8_t *buf, size_t len) {
    if (buf == NULL || len < 4) {
        return -1;
    }
    size_t limit = (len - 4) & ~(size_t)3;
    for (size_t off = 0; off <= limit; off += 4) {
        uint32_t word = (uint32_t)buf[off] | ((uint32_t)buf[off + 1] << 8) |
                        ((uint32_t)buf[off + 2] << 16) |
                        ((uint32_t)buf[off + 3] << 24);
        if (word == BOOT_SEL_APP_DESC_MAGIC) {
            return (int32_t)off;
        }
    }
    return -1;
}
