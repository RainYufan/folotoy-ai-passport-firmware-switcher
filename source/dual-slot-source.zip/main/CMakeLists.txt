# 固件选择器应用:main.c 启动选择器界面;boot_selector_model.c 为纯逻辑,
# boot_ui.c 为界面层。基线的 demo_*.c / ui_pixel.c 不再参与应用构建,
# 但文件保留(基线硬件测试示例),其宿主机测试继续由 tools/validate.sh 编译。
idf_component_register(
    SRCS "main.c"
         "boot_selector_model.c"
         "boot_ui.c"
    INCLUDE_DIRS "."
    REQUIRES app_update bsp esp_app_format esp_hw_support esp_partition esp_timer
             lvgl nvs_flash
)

# 生成的中文字体源(见 assets/fonts 与 tools/gen_fonts.sh)。
target_sources(${COMPONENT_LIB} PRIVATE
    "${CMAKE_CURRENT_LIST_DIR}/../assets/fonts/app_font_20.c"
    "${CMAKE_CURRENT_LIST_DIR}/../assets/fonts/app_font_14.c"
)

# 预装的槽 A 固件镜像:合并进 full.bin(offset 由 partitions.csv 的 slot_a 决定)。
# 先复制进构建目录再登记,/tmp 与 /private/tmp 符号链接导致的相对路径
# 差异不会影响 merge-bin 解析 flash_args。
set(SLOT_A_SRC "${CMAKE_CURRENT_LIST_DIR}/../payloads/hwtest-app.bin")
if(EXISTS "${SLOT_A_SRC}")
    file(MAKE_DIRECTORY "${CMAKE_BINARY_DIR}/payloads")
    file(COPY "${SLOT_A_SRC}" DESTINATION "${CMAKE_BINARY_DIR}/payloads")
    esptool_py_flash_to_partition(flash slot_a
        "${CMAKE_BINARY_DIR}/payloads/hwtest-app.bin")
endif()
